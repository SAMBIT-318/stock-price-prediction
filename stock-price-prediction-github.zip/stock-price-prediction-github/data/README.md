# Data

The notebook downloads AAPL historical data automatically using `yfinance`. The generated `stock_data.csv` is intentionally excluded from Git by `.gitignore`.
